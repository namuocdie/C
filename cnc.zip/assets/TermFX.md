SSN CNC TermFX

FiveM Resolver:

<<$cfx.ip>>
<<$cfx.port>>
<<$cfx.code>>
<<$cfx.country>>
<<$cfx.hosting>>
<<$cfx.org>>
<<$cfx.players.current>>
<<$cfx.players.max>>

IP Lookup:

<<$ip.ip>>
<<$ip.region>>
<<$ip.country>>
<<$ip.continent>>
<<$ip.city>>
<<$ip.zip>>
<<$ip.isp>>
<<$ip.asn>>
<<$ip.org>>
<<$ip.timezone>>

Broadcast Banner:

<<$broadcast.message>>
<<$broadcast.sender>>

Attack Sent Banner:

<<$target.host>>
<<$target.port>>
<<$target.duration>>
<<$target.method>>
<<$target.timesent>>

<<$user.ongoing>>
<<$user.concurrents>>
<<$user.maxtime>>
<<$user.username>>

Base TermFX:

<<$skipline>>
<<$clear>>
<<$general.online>>
<<$general.ongoing>>
<<$general.attackcount>>
<<$user.username>>
<<$user.ongoing>>
<<$user.concurrents>>
<<$user.maxtime>>
<<$user.vip>>
<<$user.reseller>>
<<$user.mod>>
<<$user.admin>>
<<$user.bp_powersaving>>
<<$user.bp_blacklist>>
<<$user.bp_softmaxtime>>
<<$user.expiry.days>>
<<$user.creation.days>>
<<$user.expiry.formatted>>
<<$user.creation.user>>
<<$user.creation.formatted>>
<<$user.attackcount>>

Colours:

reset: [0m
bright: [1m
dim: [2m
underscore: [4m
blink: [5m
reverse: [7m
hidden: [8m
black: [30m
bright black: [90m
background black: [40m
red: [31m
bright red: [91m
background red: [41m
green: [32m
bright green: [92m
background green: [42m
yellow: [33m
bright yellow: [93m
background yellow: [43m
blue: [34m
bright blue: [94m
background blue: [44m
magenta: [35m
bright magenta: [95m
background magenta: [45m
cyan: [36m
bright cyan: [96m
background cyan: [46m
white: [37m
bright white: [97m
background white: [47m